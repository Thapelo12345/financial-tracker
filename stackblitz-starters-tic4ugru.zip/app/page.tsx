import PageHeader from './components/ui/pageHeader'
import Balances from './components/balances'

export default function Home() {
  return (
   <div
   className='m-2 pl-4'
   >
   <PageHeader title='Overview'/>
   <Balances />
     </div>
  );
}
