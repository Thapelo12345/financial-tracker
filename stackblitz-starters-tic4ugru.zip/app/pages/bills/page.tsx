import PageHeader from '../../components/ui/pageHeader';

export default function Bills() {
  return (
    <main className="m-2 pl-4">
      <PageHeader title="Recurring Bills" />
    </main>
  );
}
