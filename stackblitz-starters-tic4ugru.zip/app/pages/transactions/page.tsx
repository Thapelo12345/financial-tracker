import PageHeader from '../../components/ui/pageHeader';
import TransactionTable from '../../components/transactionTable';
import { PlusIcon } from '@heroicons/react/24/outline'

export default function Transactions() {
  return (
    <main className="flex flex-col w-screen m-2 pl-4">
      <PageHeader title="Transactions" />

      {/* i need to add transaction and remove  */}
      <TransactionTable />
      <button className='m-2 p-2'>
       <PlusIcon className='w-4 h-4'/>
        </button>
    </main>
  );
}
