'use client'

import DashNav from './dashNav'
import MobileNav from './mobileNav'
import { useState } from 'react'

export default function Dash(){
  const [currentPage, setCurrentPage] = useState('/')
  
  return(
    <header className='bg-black/80 rounded-tr-lg rounded-br-lg'>
      <h1 className='hidden md:block font-bold text-lg text-white'>My Finances</h1>
      <DashNav />
      <MobileNav />

    </header>
  )
}