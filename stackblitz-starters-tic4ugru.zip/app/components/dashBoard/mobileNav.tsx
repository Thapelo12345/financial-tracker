import MobileLinks from '../ui/mobileLinks'
import { 
  HomeIcon,
  ArrowsUpDownIcon,
  ChartPieIcon,
  DocumentCurrencyDollarIcon,
  ReceiptRefundIcon
} from '@heroicons/react/20/solid';

export default function MobileNav(){
  return(
    <nav className='md:hidden fixed z-10 bottom-0 left-0 bg-[rgb(13,13,13)] flex flex-row justify-evenly w-full rounded-none h-auto'>

<MobileLinks pageUrl={"/"}
toolTip={'Overview'}
 icon={<HomeIcon />}
 />

<MobileLinks pageUrl={"/pages/transactions"}
toolTip={'Transactions'}
 icon={<ArrowsUpDownIcon />}
 />

 <MobileLinks pageUrl={"/pages/budget"}
toolTip={'Budgets'}
 icon={<ChartPieIcon />}
 />

 <MobileLinks pageUrl={"/pages/pots"}
 toolTip={'Pots'}
 icon={<DocumentCurrencyDollarIcon />}
 />

 <MobileLinks pageUrl={"/pages/bills"}
  toolTip={'Bills'}
 icon={<ReceiptRefundIcon />}
 />
 
    </nav>
  )
}