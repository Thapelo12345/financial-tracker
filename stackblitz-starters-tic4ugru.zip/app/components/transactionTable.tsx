'use client'

import TableHeader from '../components/ui/tableHeader';
import { TrashIcon, PencilSquareIcon } from '@heroicons/react/24/outline'
import { motion } from 'framer-motion'

const transactions: {
  date: string;
  name: string;
  description: string;
  category: string;
  type: string;
  amount: number;
}[] = [
  {
    date: '2025-07-10',
    name: 'Pick n Pay',
    description: 'Groceries for the week',
    category: 'Food',
    type: 'Expense',
    amount: 780.5,
  },
  {
    date: '2025-07-09',
    name: 'Salary',
    description: 'Monthly salary deposit',
    category: 'Income',
    type: 'Income',
    amount: 18500.0,
  },
  {
    date: '2025-07-08',
    name: 'Uber',
    description: 'Trip to work',
    category: 'Transport',
    type: 'Expense',
    amount: 95.0,
  },
  {
    date: '2025-07-07',
    name: 'Netflix',
    description: 'Monthly subscription',
    category: 'Entertainment',
    type: 'Expense',
    amount: 169.0,
  },
  {
    date: '2025-07-06',
    name: 'Cash Withdrawal',
    description: 'ATM withdrawal',
    category: 'Cash',
    type: 'Expense',
    amount: 500.0,
  },
  {
    date: '2025-07-05',
    name: 'Woolworths',
    description: 'Clothing purchase',
    category: 'Shopping',
    type: 'Expense',
    amount: 1200.0,
  },
  {
    date: '2025-07-04',
    name: 'YouTube Premium',
    description: 'Subscription fee',
    category: 'Entertainment',
    type: 'Expense',
    amount: 72.0,
  },
  {
    date: '2025-07-03',
    name: 'Electricity Bill',
    description: 'Prepaid voucher',
    category: 'Utilities',
    type: 'Expense',
    amount: 600.0,
  },
  {
    date: '2025-07-02',
    name: 'Freelance Work',
    description: 'Payment from client',
    category: 'Income',
    type: 'Income',
    amount: 3500.0,
  },
  {
    date: '2025-07-01',
    name: 'KFC',
    description: 'Dinner with friends',
    category: 'Food',
    type: 'Expense',
    amount: 230.0,
  },
];

export default function TransactionTable() {
  return (
    <div className="overflow-x-auto min-w-[589px]">
  <table className="w-full table-fixed border-separate border-spacing-y-2 min-w-max">
    <thead className='bg-white'>
      <tr>
        <TableHeader title="Date" />
        <TableHeader title="Name" />
        <TableHeader title="Description" />
        <TableHeader title="Category" />
        <TableHeader title="Type" />
        <TableHeader title="Amount" />
        {/* Optional: Add a header for actions if needed */}
        {/* <TableHeader title="Actions" /> */}
      </tr>
    </thead>

    <tbody>
      {transactions.map((transaction, index) => (
        <motion.tr
          key={index}
          className={`${index % 2 === 0 ? 'bg-blue-50' : 'bg-white/50'}`}
          whileHover={{
            scale: 1.02,
            boxShadow: '1px 9px 20px rgba(0, 0, 0, 0.4)',
          }}
        >
          <td className='text-xs text-black p-2 m-2 font-medium'>{transaction.date}</td>
          <td className='text-xs text-black p-2 m-2 font-medium'>{transaction.name}</td>
          <td className='text-xs text-black p-2 m-2 font-bold'>{transaction.description}</td>
          <td className='text-xs text-black p-2 m-2 font-medium'>{transaction.category}</td>
          <td className='text-xs text-black p-2 m-2 font-medium'>{transaction.type}</td>
          <td
            className={`${
              transaction.type === 'Expense' ? 'text-red-400' : 'text-green-400'
            } text-xs text-black font-bold p-2 m-2`}
          >
            R {transaction.amount}
          </td>
          <td className='flex items-center p-2 m-2'>
            <button className='mr-4'>
              <PencilSquareIcon className='text-blue-5400 w-4 h-4' />
            </button>
            <button>
              <TrashIcon className='text-red-500 w-4 h-4' />
            </button>
          </td>
        </motion.tr>
      ))}
    </tbody>
  </table>
</div>

  );
}
