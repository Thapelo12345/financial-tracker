
type Props ={
  title: string;
}
export default function TableHeader({ title } : Props){
  return(
    <th
    className="text-xs md:text-mdmd:p-3 md:m-2 font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 transition duration-200"
  >
    {title}
  </th>
  
  )
}