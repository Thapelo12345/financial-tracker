'use client';

type Props = {
  title: string;
  amount: number;
};

export default function BalanceContainer({ title, amount }: Props) {
  return (
    <div className="transition-all duration-1000 ease-in-out group flex flex-col bg-white hover:bg-black w-[80%] sm:1/2 md:w-56 m-2 p-2 md:p-4 rounded-[10px]">
      <h4
      className='group-hover:text-white text-black text-xs font-light'
      >{title}</h4>
      <h2
      className='group-hover:text-white text-black font-medium text-lg'
      >R {amount}</h2>
    </div>
  );
}
